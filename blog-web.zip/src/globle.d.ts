interface Window {
  $catch?: Function;
}
