import UserStore from "./module/user";

const userStore = new UserStore()

const store = {
  userStore,
};

export default store;
