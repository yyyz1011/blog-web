export const Token = "token";

export const baseUrl = "http://175.24.235.246:3000/api";